package ch.mbuehler.eth.mgis.treasurego;

/**
 * Created by marcello on 28/03/18.
 */

public enum QuestStatus {
    COMPLETED
}
